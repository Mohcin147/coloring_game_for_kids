Coloring game:

This simple game is a collection of coloring pages for children, developed by Mohcin147.

Freepik coloring pages & SVG icons of Streamlinehq.com,

SFX of Freesound.org and music by David Renda from esliyanstudios.com.